<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="items" tilewidth="129" tileheight="128" tilecount="67" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image source="../assets/Items/bomb.png" width="70" height="70"/>
 </tile>
 <tile id="1">
  <image source="../assets/Items/bombFlash.png" width="70" height="70"/>
 </tile>
 <tile id="2">
  <image source="../assets/Items/bush.png" width="70" height="70"/>
 </tile>
 <tile id="3">
  <image source="../assets/Items/buttonBlue.png" width="70" height="70"/>
 </tile>
 <tile id="4">
  <image source="../assets/Items/buttonBlue_pressed.png" width="70" height="70"/>
 </tile>
 <tile id="5">
  <image source="../assets/Items/buttonGreen.png" width="70" height="70"/>
 </tile>
 <tile id="6">
  <image source="../assets/Items/buttonGreen_pressed.png" width="70" height="70"/>
 </tile>
 <tile id="7">
  <image source="../assets/Items/buttonRed.png" width="70" height="70"/>
 </tile>
 <tile id="8">
  <image source="../assets/Items/buttonRed_pressed.png" width="70" height="70"/>
 </tile>
 <tile id="9">
  <image source="../assets/Items/buttonYellow.png" width="70" height="70"/>
 </tile>
 <tile id="10">
  <image source="../assets/Items/buttonYellow_pressed.png" width="70" height="70"/>
 </tile>
 <tile id="11">
  <image source="../assets/Items/cactus.png" width="70" height="70"/>
 </tile>
 <tile id="12">
  <image source="../assets/Items/chain.png" width="70" height="70"/>
 </tile>
 <tile id="13">
  <image source="../assets/Items/cloud1.png" width="128" height="71"/>
 </tile>
 <tile id="14">
  <image source="../assets/Items/cloud2.png" width="129" height="71"/>
 </tile>
 <tile id="15">
  <image source="../assets/Items/cloud3.png" width="129" height="71"/>
 </tile>
 <tile id="16">
  <image source="../assets/Items/coinBronze.png" width="70" height="70"/>
 </tile>
 <tile id="17">
  <image source="../assets/Items/coinGold.png" width="70" height="70"/>
 </tile>
 <tile id="18">
  <image source="../assets/Items/coinSilver.png" width="70" height="70"/>
 </tile>
 <tile id="19">
  <image source="../assets/Items/fireball.png" width="70" height="70"/>
 </tile>
 <tile id="20">
  <image source="../assets/Items/flagBlue.png" width="70" height="70"/>
 </tile>
 <tile id="21">
  <image source="../assets/Items/flagBlue_down.png" width="128" height="128"/>
 </tile>
 <tile id="22">
  <image source="../assets/Items/flagBlue1.png" width="128" height="128"/>
 </tile>
 <tile id="23">
  <image source="../assets/Items/flagBlue2.png" width="70" height="70"/>
 </tile>
 <tile id="24">
  <image source="../assets/Items/flagBlueHanging.png" width="70" height="70"/>
 </tile>
 <tile id="25">
  <image source="../assets/Items/flagGreen.png" width="70" height="70"/>
 </tile>
 <tile id="26">
  <image source="../assets/Items/flagGreen_down.png" width="128" height="128"/>
 </tile>
 <tile id="27">
  <image source="../assets/Items/flagGreen1.png" width="128" height="128"/>
 </tile>
 <tile id="28">
  <image source="../assets/Items/flagGreen2.png" width="70" height="70"/>
 </tile>
 <tile id="29">
  <image source="../assets/Items/flagGreenHanging.png" width="70" height="70"/>
 </tile>
 <tile id="30">
  <image source="../assets/Items/flagRed.png" width="70" height="70"/>
 </tile>
 <tile id="31">
  <image source="../assets/Items/flagRed_down.png" width="128" height="128"/>
 </tile>
 <tile id="32">
  <image source="../assets/Items/flagRed1.png" width="128" height="128"/>
 </tile>
 <tile id="33">
  <image source="../assets/Items/flagRed2.png" width="70" height="70"/>
 </tile>
 <tile id="34">
  <image source="../assets/Items/flagRedHanging.png" width="70" height="70"/>
 </tile>
 <tile id="35">
  <image source="../assets/Items/flagYellow.png" width="70" height="70"/>
 </tile>
 <tile id="36">
  <image source="../assets/Items/flagYellow_down.png" width="128" height="128"/>
 </tile>
 <tile id="37">
  <image source="../assets/Items/flagYellow1.png" width="128" height="128"/>
 </tile>
 <tile id="38">
  <image source="../assets/Items/flagYellow2.png" width="70" height="70"/>
 </tile>
 <tile id="39">
  <image source="../assets/Items/flagYellowHanging.png" width="70" height="70"/>
 </tile>
 <tile id="40">
  <image source="../assets/Items/gemBlue.png" width="70" height="70"/>
 </tile>
 <tile id="41">
  <image source="../assets/Items/gemGreen.png" width="70" height="70"/>
 </tile>
 <tile id="42">
  <image source="../assets/Items/gemRed.png" width="70" height="70"/>
 </tile>
 <tile id="43">
  <image source="../assets/Items/gemYellow.png" width="70" height="70"/>
 </tile>
 <tile id="44">
  <image source="../assets/Items/keyBlue.png" width="70" height="70"/>
 </tile>
 <tile id="45">
  <image source="../assets/Items/keyGreen.png" width="70" height="70"/>
 </tile>
 <tile id="46">
  <image source="../assets/Items/keyRed.png" width="70" height="70"/>
 </tile>
 <tile id="47">
  <image source="../assets/Items/keyYellow.png" width="70" height="70"/>
 </tile>
 <tile id="48">
  <image source="../assets/Items/mushroomBrown.png" width="70" height="70"/>
 </tile>
 <tile id="49">
  <image source="../assets/Items/mushroomRed.png" width="70" height="70"/>
 </tile>
 <tile id="50">
  <image source="../assets/Items/particleBrick1a.png" width="19" height="14"/>
 </tile>
 <tile id="51">
  <image source="../assets/Items/particleBrick1b.png" width="21" height="21"/>
 </tile>
 <tile id="52">
  <image source="../assets/Items/particleBrick2a.png" width="19" height="14"/>
 </tile>
 <tile id="53">
  <image source="../assets/Items/particleBrick2b.png" width="21" height="21"/>
 </tile>
 <tile id="54">
  <image source="../assets/Items/plant.png" width="70" height="70"/>
 </tile>
 <tile id="55">
  <image source="../assets/Items/plantPurple.png" width="70" height="70"/>
 </tile>
 <tile id="56">
  <image source="../assets/Items/rock.png" width="70" height="70"/>
 </tile>
 <tile id="57">
  <image source="../assets/Items/snowhill.png" width="70" height="70"/>
 </tile>
 <tile id="58">
  <image source="../assets/Items/spikes.png" width="70" height="70"/>
 </tile>
 <tile id="59">
  <image source="../assets/Items/springboardDown.png" width="70" height="70"/>
 </tile>
 <tile id="60">
  <image source="../assets/Items/springboardUp.png" width="70" height="70"/>
 </tile>
 <tile id="61">
  <image source="../assets/Items/star.png" width="70" height="70"/>
 </tile>
 <tile id="62">
  <image source="../assets/Items/switchLeft.png" width="70" height="70"/>
 </tile>
 <tile id="63">
  <image source="../assets/Items/switchMid.png" width="70" height="70"/>
 </tile>
 <tile id="64">
  <image source="../assets/Items/switchRight.png" width="70" height="70"/>
 </tile>
 <tile id="65">
  <image source="../assets/Items/weight.png" width="70" height="70"/>
 </tile>
 <tile id="66">
  <image source="../assets/Items/weightChained.png" width="70" height="70"/>
 </tile>
</tileset>
