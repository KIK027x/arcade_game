<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="ice" tilewidth="70" tileheight="70" tilecount="98" columns="14">
 <image source="../assets/Backgrounds/sheet1.png" width="980" height="490"/>
</tileset>
