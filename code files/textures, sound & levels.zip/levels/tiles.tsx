<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="tiles" tilewidth="70" tileheight="70" spacing="2" tilecount="156" columns="12">
 <image source="../assets/Tiles/tiles_spritesheet.png" width="914" height="936"/>
</tileset>
