<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="12345" tilewidth="88" tileheight="147" tilecount="100" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image source="../assets/Enemies/barnacle.png" width="51" height="57"/>
 </tile>
 <tile id="1">
  <image source="../assets/Enemies/barnacle_bite.png" width="51" height="58"/>
 </tile>
 <tile id="2">
  <image source="../assets/Enemies/barnacle_dead.png" width="51" height="57"/>
 </tile>
 <tile id="3">
  <image source="../assets/Enemies/barnacle_hit.png" width="51" height="57"/>
 </tile>
 <tile id="4">
  <image source="../assets/Enemies/bat.png" width="70" height="47"/>
 </tile>
 <tile id="5">
  <image source="../assets/Enemies/bat_dead.png" width="70" height="47"/>
 </tile>
 <tile id="6">
  <image source="../assets/Enemies/bat_fly.png" width="88" height="37"/>
 </tile>
 <tile id="7">
  <image source="../assets/Enemies/bat_hang.png" width="38" height="48"/>
 </tile>
 <tile id="8">
  <image source="../assets/Enemies/bat_hit.png" width="70" height="47"/>
 </tile>
 <tile id="9">
  <image source="../assets/Enemies/bee.png" width="56" height="48"/>
 </tile>
 <tile id="10">
  <image source="../assets/Enemies/bee_dead.png" width="56" height="48"/>
 </tile>
 <tile id="11">
  <image source="../assets/Enemies/bee_fly.png" width="61" height="42"/>
 </tile>
 <tile id="12">
  <image source="../assets/Enemies/bee_hit.png" width="56" height="48"/>
 </tile>
 <tile id="13">
  <image source="../assets/Enemies/fishGreen.png" width="60" height="45"/>
 </tile>
 <tile id="14">
  <image source="../assets/Enemies/fishGreen_dead.png" width="60" height="45"/>
 </tile>
 <tile id="15">
  <image source="../assets/Enemies/fishGreen_hit.png" width="57" height="44"/>
 </tile>
 <tile id="16">
  <image source="../assets/Enemies/fishGreen_swim.png" width="57" height="44"/>
 </tile>
 <tile id="17">
  <image source="../assets/Enemies/fishPink.png" width="60" height="45"/>
 </tile>
 <tile id="18">
  <image source="../assets/Enemies/fishPink_dead.png" width="60" height="45"/>
 </tile>
 <tile id="19">
  <image source="../assets/Enemies/fishPink_hit.png" width="57" height="44"/>
 </tile>
 <tile id="20">
  <image source="../assets/Enemies/fishPink_swim.png" width="57" height="44"/>
 </tile>
 <tile id="21">
  <image source="../assets/Enemies/fly.png" width="57" height="45"/>
 </tile>
 <tile id="22">
  <image source="../assets/Enemies/fly_dead.png" width="57" height="45"/>
 </tile>
 <tile id="23">
  <image source="../assets/Enemies/fly_fly.png" width="65" height="39"/>
 </tile>
 <tile id="24">
  <image source="../assets/Enemies/fly_hit.png" width="57" height="45"/>
 </tile>
 <tile id="25">
  <image source="../assets/Enemies/frog.png" width="58" height="39"/>
 </tile>
 <tile id="26">
  <image source="../assets/Enemies/frog_dead.png" width="61" height="54"/>
 </tile>
 <tile id="27">
  <image source="../assets/Enemies/frog_hit.png" width="61" height="54"/>
 </tile>
 <tile id="28">
  <image source="../assets/Enemies/frog_leap.png" width="61" height="54"/>
 </tile>
 <tile id="29">
  <image source="../assets/Enemies/ghost.png" width="51" height="73"/>
 </tile>
 <tile id="30">
  <image source="../assets/Enemies/ghost_dead.png" width="51" height="73"/>
 </tile>
 <tile id="31">
  <image source="../assets/Enemies/ghost_hit.png" width="51" height="73"/>
 </tile>
 <tile id="32">
  <image source="../assets/Enemies/ghost_normal.png" width="51" height="73"/>
 </tile>
 <tile id="33">
  <image source="../assets/Enemies/grassBlock.png" width="71" height="70"/>
 </tile>
 <tile id="34">
  <image source="../assets/Enemies/grassBlock_dead.png" width="71" height="70"/>
 </tile>
 <tile id="35">
  <image source="../assets/Enemies/grassBlock_hit.png" width="71" height="70"/>
 </tile>
 <tile id="36">
  <image source="../assets/Enemies/grassBlock_jump.png" width="71" height="70"/>
 </tile>
 <tile id="37">
  <image source="../assets/Enemies/ladyBug.png" width="58" height="34"/>
 </tile>
 <tile id="38">
  <image source="../assets/Enemies/ladyBug_fly.png" width="59" height="42"/>
 </tile>
 <tile id="39">
  <image source="../assets/Enemies/ladyBug_hit.png" width="58" height="34"/>
 </tile>
 <tile id="40">
  <image source="../assets/Enemies/ladyBug_walk.png" width="61" height="34"/>
 </tile>
 <tile id="41">
  <image source="../assets/Enemies/mouse.png" width="59" height="35"/>
 </tile>
 <tile id="42">
  <image source="../assets/Enemies/mouse_dead.png" width="59" height="35"/>
 </tile>
 <tile id="43">
  <image source="../assets/Enemies/mouse_hit.png" width="59" height="35"/>
 </tile>
 <tile id="44">
  <image source="../assets/Enemies/mouse_walk.png" width="58" height="35"/>
 </tile>
 <tile id="45">
  <image source="../assets/Enemies/piranha.png" width="45" height="60"/>
 </tile>
 <tile id="46">
  <image source="../assets/Enemies/piranha_dead.png" width="45" height="60"/>
 </tile>
 <tile id="47">
  <image source="../assets/Enemies/piranha_down.png" width="45" height="60"/>
 </tile>
 <tile id="48">
  <image source="../assets/Enemies/piranha_hit.png" width="45" height="60"/>
 </tile>
 <tile id="49">
  <image source="../assets/Enemies/slime.png" width="49" height="34"/>
 </tile>
 <tile id="50">
  <image source="../assets/Enemies/slime_dead.png" width="49" height="34"/>
 </tile>
 <tile id="51">
  <image source="../assets/Enemies/slime_hit.png" width="49" height="34"/>
 </tile>
 <tile id="52">
  <image source="../assets/Enemies/slime_squashed.png" width="57" height="13"/>
 </tile>
 <tile id="53">
  <image source="../assets/Enemies/slime_walk.png" width="57" height="30"/>
 </tile>
 <tile id="54">
  <image source="../assets/Enemies/slimeBlock.png" width="51" height="50"/>
 </tile>
 <tile id="55">
  <image source="../assets/Enemies/slimeBlock_dead.png" width="51" height="50"/>
 </tile>
 <tile id="56">
  <image source="../assets/Enemies/slimeBlock_hit.png" width="51" height="50"/>
 </tile>
 <tile id="57">
  <image source="../assets/Enemies/slimeBlue.png" width="49" height="34"/>
 </tile>
 <tile id="58">
  <image source="../assets/Enemies/slimeBlue_blue.png" width="57" height="30"/>
 </tile>
 <tile id="59">
  <image source="../assets/Enemies/slimeBlue_dead.png" width="49" height="34"/>
 </tile>
 <tile id="60">
  <image source="../assets/Enemies/slimeBlue_hit.png" width="49" height="34"/>
 </tile>
 <tile id="61">
  <image source="../assets/Enemies/slimeBlue_squashed.png" width="57" height="13"/>
 </tile>
 <tile id="62">
  <image source="../assets/Enemies/slimeGreen.png" width="49" height="34"/>
 </tile>
 <tile id="63">
  <image source="../assets/Enemies/slimeGreen_dead.png" width="49" height="34"/>
 </tile>
 <tile id="64">
  <image source="../assets/Enemies/slimeGreen_hit.png" width="49" height="34"/>
 </tile>
 <tile id="65">
  <image source="../assets/Enemies/slimeGreen_squashed.png" width="57" height="13"/>
 </tile>
 <tile id="66">
  <image source="../assets/Enemies/slimeGreen_walk.png" width="57" height="30"/>
 </tile>
 <tile id="67">
  <image source="../assets/Enemies/snail.png" width="55" height="40"/>
 </tile>
 <tile id="68">
  <image source="../assets/Enemies/snail_hit.png" width="55" height="40"/>
 </tile>
 <tile id="69">
  <image source="../assets/Enemies/snail_shell.png" width="43" height="35"/>
 </tile>
 <tile id="70">
  <image source="../assets/Enemies/snail_walk.png" width="60" height="40"/>
 </tile>
 <tile id="71">
  <image source="../assets/Enemies/snake.png" width="63" height="23"/>
 </tile>
 <tile id="72">
  <image source="../assets/Enemies/snake_dead.png" width="63" height="23"/>
 </tile>
 <tile id="73">
  <image source="../assets/Enemies/snake_hit.png" width="63" height="23"/>
 </tile>
 <tile id="74">
  <image source="../assets/Enemies/snake_walk.png" width="63" height="23"/>
 </tile>
 <tile id="75">
  <image source="../assets/Enemies/snakeLava.png" width="53" height="147"/>
 </tile>
 <tile id="76">
  <image source="../assets/Enemies/snakeLava_ani.png" width="52" height="147"/>
 </tile>
 <tile id="77">
  <image source="../assets/Enemies/snakeLava_dead.png" width="53" height="147"/>
 </tile>
 <tile id="78">
  <image source="../assets/Enemies/snakeLava_hit.png" width="53" height="147"/>
 </tile>
 <tile id="79">
  <image source="../assets/Enemies/snakeSlime.png" width="53" height="147"/>
 </tile>
 <tile id="80">
  <image source="../assets/Enemies/snakeSlime_ani.png" width="52" height="147"/>
 </tile>
 <tile id="81">
  <image source="../assets/Enemies/snakeSlime_dead.png" width="53" height="147"/>
 </tile>
 <tile id="82">
  <image source="../assets/Enemies/snakeSlime_hit.png" width="53" height="147"/>
 </tile>
 <tile id="83">
  <image source="../assets/Enemies/spider.png" width="71" height="45"/>
 </tile>
 <tile id="84">
  <image source="../assets/Enemies/spider_dead.png" width="69" height="51"/>
 </tile>
 <tile id="85">
  <image source="../assets/Enemies/spider_hit.png" width="71" height="45"/>
 </tile>
 <tile id="86">
  <image source="../assets/Enemies/spider_walk1.png" width="72" height="51"/>
 </tile>
 <tile id="87">
  <image source="../assets/Enemies/spider_walk2.png" width="77" height="53"/>
 </tile>
 <tile id="88">
  <image source="../assets/Enemies/spinner.png" width="63" height="62"/>
 </tile>
 <tile id="89">
  <image source="../assets/Enemies/spinner_dead.png" width="63" height="62"/>
 </tile>
 <tile id="90">
  <image source="../assets/Enemies/spinner_hit.png" width="61" height="61"/>
 </tile>
 <tile id="91">
  <image source="../assets/Enemies/spinner_spin.png" width="61" height="61"/>
 </tile>
 <tile id="92">
  <image source="../assets/Enemies/spinnerHalf.png" width="63" height="31"/>
 </tile>
 <tile id="93">
  <image source="../assets/Enemies/spinnerHalf_dead.png" width="63" height="31"/>
 </tile>
 <tile id="94">
  <image source="../assets/Enemies/spinnerHalf_hit.png" width="61" height="30"/>
 </tile>
 <tile id="95">
  <image source="../assets/Enemies/spinnerHalf_spin.png" width="61" height="30"/>
 </tile>
 <tile id="96">
  <image source="../assets/Enemies/worm.png" width="63" height="23"/>
 </tile>
 <tile id="97">
  <image source="../assets/Enemies/worm_dead.png" width="63" height="23"/>
 </tile>
 <tile id="98">
  <image source="../assets/Enemies/worm_hit.png" width="63" height="23"/>
 </tile>
 <tile id="99">
  <image source="../assets/Enemies/worm_walk.png" width="63" height="23"/>
 </tile>
</tileset>
